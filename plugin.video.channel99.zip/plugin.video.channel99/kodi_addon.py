import sys
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.parse import urlencode, parse_qsl

# Get the plugin url in plugin:// notation
_URL = sys.argv[0]
# Get the plugin handle as an integer number
_HANDLE = int(sys.argv[1])

# Addon info
ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')

# Channel categories and streams
CHANNELS = {
    'Anime Streams': [
        {
            'name': 'Channel 99 - All Anime',
            'url': 'http://155.138.139.156:8099/;stream.nsv',
            'description': '14,841 episodes/movies as of 2025! The original stream, still the most frequently updated. 240p VP3.1 & MP3 audio.',
            'quality': '240p'
        },
        {
            'name': 'Channel 99½ - All Anime (Offset)',
            'url': 'http://155.138.139.156:8199/;stream.nsv',
            'description': 'Same playlist as 99, but offset by about 7 months. Format changed Jan 2024.',
            'quality': '240p'
        },
        {
            'name': 'Channel 99 Classic - Anime from Last Century',
            'url': 'http://155.138.139.156:8060/;stream.nsv',
            'description': 'All Anime from the 1900s! Classic animation preserved in NSV format.',
            'quality': '240p'
        },
        {
            'name': 'Channel 99 HD - All Anime in HD',
            'url': 'http://155.138.139.156:9999/;stream.nsv',
            'description': 'All Anime in 720p HD. Pushing the limits of VP3! 5,237 files in HD LTS.',
            'quality': '720p HD'
        },
        {
            'name': 'Channel 2501 - Ghost in the Shell',
            'url': 'http://155.138.139.156:2501/;stream.nsv',
            'description': 'All Ghost in the Shell, all the time! In glorious 720p HD NSV!',
            'quality': '720p HD'
        },
        {
            'name': 'Channel 4869 - Detective Conan',
            'url': 'http://155.138.139.156:4869/;stream.nsv',
            'description': 'All Detective Conan, all the time! In glorious 720p HD NSV!',
            'quality': '720p HD'
        },
    ],
    'Nonfiction Streams': [
        {
            'name': 'Channel 101 - Documentaries',
            'url': 'http://155.138.139.156:8101/;stream.nsv',
            'description': 'Documentaries and film reels from last century. Rearranged playlist for 2025.',
            'quality': '240p'
        },
        {
            'name': 'Channel 101½ - Documentaries Remix',
            'url': 'http://155.138.139.156:9101/;stream.nsv',
            'description': 'A remix of channel 101 - Same content, randomized order.',
            'quality': '240p'
        },
        {
            'name': 'Channel 101 Dropout',
            'url': 'http://155.138.139.156:2007/;stream.nsv',
            'description': 'Documentaries rejected from Channel 101. Changed around for 2025.',
            'quality': '240p'
        },
    ],
    'Fiction Streams': [
        {
            'name': 'Channel 3000 - Mystery Science Theater 3000',
            'url': 'http://155.138.139.156:3000/;stream.nsv',
            'description': 'The obligatory MST3K stream. Continuing the tradition of MST3K on NSV!',
            'quality': '240p'
        },
        {
            'name': 'Channel 3000½ - MST3K Remix',
            'url': 'http://155.138.139.156:3002/;stream.nsv',
            'description': 'A remix of Channel 3000 - Same content, randomized order.',
            'quality': '240p'
        },
        {
            'name': 'Channel 42 - Miscellaneous Fiction',
            'url': 'http://155.138.139.156:8042/;stream.nsv',
            'description': 'Miscellaneous Fiction (non-anime). Being fleshed out with new content in 2025.',
            'quality': '240p'
        },
    ],
    'Miscellaneous Streams': [
        {
            'name': 'Channel 19.5 - Experience Yesterday Today',
            'url': 'http://155.138.139.156:9150/;stream.nsv',
            'description': 'A public service of Moonbase 19.5 - "Experience Yesterday Today"',
            'quality': '240p'
        },
        {
            'name': 'Cosmos TV Classic',
            'url': 'http://155.138.139.156:8010/;stream.nsv',
            'description': 'A clone of Cosmos TV ca. 2011. Space docs and UFO trash. Files are messy, stream may misbehave.',
            'quality': '240p'
        },
        {
            'name': 'Rant TV Classic',
            'url': 'http://155.138.139.156:8000/;stream.nsv',
            'description': 'A clone of Rant TV (www.rantmedia.ca) from ca. 2010. Plus the "What The Hell Show" VHS rips.',
            'quality': '240p'
        },
        {
            'name': "Icenrye's Geocaching Videostream",
            'url': 'http://155.138.139.156:8095/;stream.nsv',
            'description': 'A cult classic. This stream is all Icenrye, all the time.',
            'quality': '240p'
        },
    ],
}

INFO_TEXT = """[COLOR yellow][B]Channel 99 - Retro IPTV from 2003[/B][/COLOR]

NSV Streams are an early form of online streaming video from the pre-YouTube era.
Born in 2003, popular until 2006, and supposedly died in 2013... but still alive!

[B]About the Streams:[/B]
• Most streams are 240p (320x240) VP3.1 & MP3 audio, ~256kbps
• HD streams are 720p using the same VP3 codecs
• Free to watch - no advertisements anywhere, ever
• Still actively updated with new content in 2025!
• 150-200 viewer hours per day on average

[B]Technology:[/B]
NSV (Nullsoft Streaming Video) preserves IPTV technology from circa 2003.
These streams stay true to the original format for posterity's sake.

Visit: www.pracdev.org/channel99/
Join the small but dedicated cult following bringing back retro IPTV!"""


def get_url(**kwargs):
    """Create a URL for calling the plugin recursively from the given set of keyword arguments."""
    return '{}?{}'.format(_URL, urlencode(kwargs))


def show_info():
    """Display information about Channel 99."""
    dialog = xbmcgui.Dialog()
    dialog.textviewer('About Channel 99 NSV Streams', INFO_TEXT)


def list_categories():
    """Create the list of video categories in the Kodi interface."""
    xbmcplugin.setPluginCategory(_HANDLE, 'Channel 99')
    xbmcplugin.setContent(_HANDLE, 'videos')
    
    # Add info item at the top
    list_item = xbmcgui.ListItem(label='[COLOR yellow]ℹ About Channel 99[/COLOR]')
    list_item.setArt({'icon': 'DefaultAddonHelper.png'})
    list_item.setInfo('video', {'title': 'About Channel 99', 'plot': 'Learn about NSV Streams and Channel 99'})
    url = get_url(action='info')
    xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, False)
    
    # Add categories
    for category in CHANNELS.keys():
        list_item = xbmcgui.ListItem(label=category)
        list_item.setArt({'icon': 'DefaultFolder.png'})
        channel_count = len(CHANNELS[category])
        list_item.setInfo('video', {
            'title': category,
            'genre': 'NSV Streams',
            'plot': f'{channel_count} channels available'
        })
        
        url = get_url(action='listing', category=category)
        is_folder = True
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    
    xbmcplugin.endOfDirectory(_HANDLE)


def list_channels(category):
    """Create the list of playable videos in the Kodi interface."""
    xbmcplugin.setPluginCategory(_HANDLE, category)
    xbmcplugin.setContent(_HANDLE, 'videos')
    
    channels = CHANNELS.get(category, [])
    
    for channel in channels:
        list_item = xbmcgui.ListItem(label=channel['name'])
        list_item.setArt({'icon': 'DefaultVideo.png'})
        
        # Add detailed info
        plot = channel.get('description', '')
        quality = channel.get('quality', '240p')
        plot += f'\n\n[B]Quality:[/B] {quality}\n[B]Format:[/B] NSV (VP3 + MP3)'
        
        list_item.setInfo('video', {
            'title': channel['name'],
            'genre': category,
            'plot': plot,
            'mediatype': 'video'
        })
        list_item.setProperty('IsPlayable', 'true')
        
        url = get_url(action='play', video=channel['url'])
        is_folder = False
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    
    xbmcplugin.endOfDirectory(_HANDLE)


def play_video(path):
    """Play a video by the provided path."""
    play_item = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=play_item)


def router(paramstring):
    """Router function that calls other functions depending on the provided paramstring."""
    params = dict(parse_qsl(paramstring))
    
    if params:
        if params['action'] == 'listing':
            list_channels(params['category'])
        elif params['action'] == 'play':
            play_video(params['video'])
        elif params['action'] == 'info':
            show_info()
        else:
            raise ValueError('Invalid paramstring: {}!'.format(paramstring))
    else:
        list_categories()


if __name__ == '__main__':
    router(sys.argv[2][1:])